package ec.edu.espe.petshopinventorycontrol.controller;

import ec.edu.espe.petshopinventorycontrol.model.services.LoginRequest;
import ec.edu.espe.petshopinventorycontrol.model.services.UserAccount;
import java.util.Optional;

public final class LoginController {

    public void onCreateAccount(LoginView view) {
        view.openRegister();
        view.close();
    }

    public void onSignIn(LoginView view) {
        try {
            String username = view.getUsername();
            String password = view.getPassword();

            if (username == null || username.trim().isEmpty()
                    || password == null || password.isEmpty()) {
                view.showMessage(
                        "Please enter username and password.",
                        "Validation error",
                        javax.swing.JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            LoginRequest request = new LoginRequest(username, password);
            Optional<UserAccount> userOpt = AuthDependencies.getAuthService().login(request);

            if (userOpt.isEmpty()) {
                view.showMessage(
                        "Invalid username or password.",
                        "Access denied",
                        javax.swing.JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            UserAccount user = userOpt.get();
            String fullName = user.getFirstName() + " " + user.getLastName();
            view.showMessage(
                    "Login successful. Welcome, " + fullName + "!",
                    "Welcome",
                    javax.swing.JOptionPane.INFORMATION_MESSAGE
            );
        } catch (Exception ex) {
            view.showMessage(
                    "Unexpected error: " + ex.getMessage(),
                    "Error",
                    javax.swing.JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
